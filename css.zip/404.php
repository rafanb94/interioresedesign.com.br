<?php get_header();?>
<div style="display:flex; justify-content:center; align-items:center; height:calc(100vh - 379px)">
  <h2>Página não encontrada</h2>
</div>

<?php get_footer();?>	